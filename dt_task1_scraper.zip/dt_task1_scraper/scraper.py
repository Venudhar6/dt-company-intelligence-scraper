import requests
from bs4 import BeautifulSoup
import sys
import re
import json
from urllib.parse import urljoin, urlparse
from datetime import datetime

# -----------------------------
# Helper function to fetch page
# -----------------------------
def fetch_page(url, errors):
    try:
        response = requests.get(url, timeout=10, headers={"User-Agent": "Mozilla/5.0"})
        if response.status_code == 200:
            return response.text
        else:
            errors.append(f"Failed to fetch {url} | Status code: {response.status_code}")
            return None
    except Exception as e:
        errors.append(f"Error fetching {url} | {str(e)}")
        return None


# -----------------------------
# Extract emails & phones
# -----------------------------
def extract_contacts(text):
    emails = list(set(re.findall(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", text)))
    phones = list(set(re.findall(r"\+?\d[\d\s\-()]{8,}", text)))
    return emails, phones


# -----------------------------
# Main scraper logic
# -----------------------------
def scrape_company(url):
    output = {
        "identity": {
            "company_name": "Not found",
            "website_url": url,
            "tagline": "Not found"
        },
        "business_summary": {
            "what_they_do": "Not found",
            "primary_offerings": [],
            "target_customers": "Not found"
        },
        "evidence": {
            "key_pages_detected": [],
            "signals": [],
            "social_links": {}
        },
        "contact_location": {
            "emails": [],
            "phones": [],
            "address": "Not found",
            "contact_page_url": "Not found"
        },
        "team_hiring": {
            "careers_page_url": "Not found",
            "roles_mentioned": []
        },
        "metadata": {
            "timestamp": datetime.now().isoformat(),
            "pages_visited": [],
            "errors": []
        }
    }

    homepage_html = fetch_page(url, output["metadata"]["errors"])
    if not homepage_html:
        return output

    soup = BeautifulSoup(homepage_html, "html.parser")
    output["metadata"]["pages_visited"].append(url)

    # -----------------------------
    # Identity
    # -----------------------------
    if soup.title:
        output["identity"]["company_name"] = soup.title.text.strip()

    meta_desc = soup.find("meta", attrs={"name": "description"})
    if meta_desc and meta_desc.get("content"):
        output["identity"]["tagline"] = meta_desc.get("content").strip()

    # -----------------------------
    # Find important links
    # -----------------------------
    important_keywords = ["about", "company", "product", "solution", "industry",
                          "pricing", "contact", "career", "job"]
    links = soup.find_all("a", href=True)

    important_pages = {}

    for link in links:
        href = link.get("href").lower()
        for key in important_keywords:
            if key in href and key not in important_pages:
                full_url = urljoin(url, link.get("href"))
                important_pages[key] = full_url

    # Limit pages
    important_pages = dict(list(important_pages.items())[:12])

    # -----------------------------
    # Visit important pages
    # -----------------------------
    full_text = soup.get_text(separator=" ", strip=True)

    for key, page_url in important_pages.items():
        page_html = fetch_page(page_url, output["metadata"]["errors"])
        if not page_html:
            continue

        page_soup = BeautifulSoup(page_html, "html.parser")
        output["metadata"]["pages_visited"].append(page_url)
        output["evidence"]["key_pages_detected"].append(page_url)

        page_text = page_soup.get_text(separator=" ", strip=True)
        full_text += " " + page_text

        # Contact page
        if "contact" in key:
            output["contact_location"]["contact_page_url"] = page_url

        # Careers page
        if "career" in key or "job" in key:
            output["team_hiring"]["careers_page_url"] = page_url

    # -----------------------------
    # Business Summary (light interpretation)
    # -----------------------------
    paragraphs = soup.find_all("p")
    summary_text = " ".join([p.text.strip() for p in paragraphs[:3]])
    if summary_text:
        output["business_summary"]["what_they_do"] = summary_text

    # -----------------------------
    # Evidence signals
    # -----------------------------
    signal_keywords = ["client", "case study", "certification", "award", "trusted by", "testimonial"]
    for keyword in signal_keywords:
        if keyword in full_text.lower():
            output["evidence"]["signals"].append(keyword)

    # -----------------------------
    # Social links
    # -----------------------------
    social_domains = {
        "linkedin": "linkedin.com",
        "twitter": "twitter.com",
        "youtube": "youtube.com",
        "instagram": "instagram.com"
    }

    for a in soup.find_all("a", href=True):
        for name, domain in social_domains.items():
            if domain in a["href"]:
                output["evidence"]["social_links"][name] = a["href"]

    # -----------------------------
    # Contact details
    # -----------------------------
    emails, phones = extract_contacts(full_text)
    output["contact_location"]["emails"] = emails if emails else []
    output["contact_location"]["phones"] = phones if phones else []

    return output


# -----------------------------
# Main execution
# -----------------------------
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python scraper.py <website_url>")
        sys.exit(1)

    website_url = sys.argv[1]

    result = scrape_company(website_url)

    domain = urlparse(website_url).netloc.replace(".", "_")
    output_file = f"outputs/{domain}_output.json"

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=4)

    print(f"Scraping completed. Output saved to {output_file}")
